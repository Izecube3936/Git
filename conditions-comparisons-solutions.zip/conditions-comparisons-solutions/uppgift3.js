/*
Skapa ett program som låter användaren välja en form genom att skriva in circle/rectangle/triangle. 
Programmet ska baserat på användarens val be om input för att beräkna den valda formens area. 
När användaren fått svara med den data som behövs ska en uträkning på arean ska och programmet skriver ut resultatet 

Gör en flowchart och sedan skriva pseudokod innan ni börjar koda.
*/

/**
 * PSEUDOKOD
 * 
 * Ange figur (circle/rectangle/triangle)
 * 
 * Om circle
 *     ange radie
 *     räkna ut area
 *     visa result
 * Om rectangle
 *     ange höjd
 *     ange bredd
 *     räkna ut area
 *     visa result
 * Om triangle
 *     ange höjd
 *     ange bredd
 *     räkna ut area
 *     visa result
 */

const val = prompt("Hej! Vilken typ av form vill du räkna ut aren på; cirkel, triangel eller rektangel?");
console.log(val);
    
    
if (val == "cirkel") {
    const cirkelDiameter = prompt("Ange cirkelns diameter");
    console.log(cirkelDiameter);
    const cirkelRadie = cirkelDiameter / 2;
    console.log(cirkelRadie);
    // const cirkelArea = cirkelRadie * cirkelRadie * Math.PI;
    // const cirkelArea = cirkelRadie**2 * Math.PI;
    const cirkelArea = Math.pow(cirkelRadie, 2) * Math.PI;
    alert("Cirkelns area är " + cirkelArea);
} else if (val == "triangel") {
    const triangelBas = prompt("Ange triangelns bas");
    console.log(triangelBas);
    const triangelHojd = prompt("Ange triangelns höjd");
    console.log(triangelHojd);
    const triangelArea = (triangelBas * triangelHojd) / 2;
    alert("Triangelns area är " + triangelArea);
} else if (val == "rektangel") {
    const rektangelBas = prompt("Ange rektangelns bas");
    console.log(rektangelBas);
    const rektangelHojd = prompt("Ange rektangelns höjd");
    console.log(rektangelHojd);
    const rektangelArea = rektangelBas * rektangelHojd;
    alert("rektangelns area är " + rektangelArea);
} else {
    alert("Du stavade fel");
}