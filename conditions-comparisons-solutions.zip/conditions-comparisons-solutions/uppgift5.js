/*
Med den kunskap ni fått från föregående 9 uppgifter, skapa spelet sten/sax/påse som kan spelas mot datorn. 
Spela det verkliga spelet med en vän för att se hur processen går till. 
Översätt sedan detta till pseudokod eller en flowchart innan ni börjar programmera. 
Kom ihåg att bryta ner problemet i flera moduler och få dessa att funka separat.

Parprogrammering uppmuntras. Använd er av tekniker från tidigare uppgifter för att lösa denna uppgift.
*/

var nummer = Math.random();
console.log(nummer);
nummer = nummer * 2;
console.log(nummer);
nummer = Math.round(nummer);
console.log(nummer);
/**
* sten = 0
* sax = 1
* påse = 2
**/

let computerChoice = '';
if (nummer === 0) {
    computerChoice = 'sten';
} else if (nummer === 1) {
    computerChoice = 'sax';
} else if (nummer === 2) {
    computerChoice = 'påse';
}


const userChoise = prompt(`Hej! sten, sax eller påse? CHEAT (${computerChoice})`);
console.log(userChoise);


/**
 * När vinner Användaren
 * 
 * ----------------------
 * Användaren  |   Datorn
 * ----------------------
 * Sten        |   Sax
 * Sax         |   Påse
 * Påse        |   Sten
 */

// Lösningsförslag 1
// if (computerChoice == userChoise) {
//     alert("Lika! Kör igen!");
// } else if (userChoise == "sten" && computerChoice == "sax") {
//     alert('Du vann');
// } else if (userChoise == "sax" && computerChoice == "påse") {
//     alert('Du vann');
// } else if (userChoise == "påse" && computerChoice == "sten") {
//     alert('Du vann');
// } else {
//     alert('Datorn vann');
// }

// Lösningsförslag 2
if (computerChoice == userChoise) {
    alert("Lika! Kör igen!");
} else if (
    (userChoise == "sten" && computerChoice == "sax") || 
    (userChoise == "sax" && computerChoice == "påse") || 
    (userChoise == "påse" && computerChoice == "sten")
) {
    alert('Du vann');
} else {
    alert('Datorn vann');
}

