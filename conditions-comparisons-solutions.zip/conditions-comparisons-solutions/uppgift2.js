/* Skriv ett program där du får en förfrågan om ett lösenord. 
Lösenordet ska vara satt till en variabel i din kod och ENDAST om användaren skriver rätt lösenord 
ska texten "Välkommen" visas. Om användaren skriver fel lösenord ska texten "Inkräktare" visas. 
Användarens svar ska sparas som en variabel. 
Använd if och en else för att lösa problemet. 
Om det är rätt, gör det här, annars gör det här

Gör en flowchart och sedan skriva pseudokod innan ni börjar koda.

*/

/**
 * PSEUDOKOD
 * 
 * Fråga efter lösenord
 * 
 * Är lösenordet korrekt?
 *      "Välkommen"
 * Annars
 *      "Inkräktare"
 */

// Lösningsförslag 1
// let userInput = prompt('Ange lösenord');
// let correctPassword = "12345";

// if (userInput == correctPassword) {
//     alert('Välkommen');
// } else {
//     alert('Inkräktare');
// }

// Lösningsförslag 2 med Ternary operator
let userInput = prompt('Ange lösenord');
let correctPassword = "12345";

let message = userInput == correctPassword ? 'Välkommen' : 'Inkräktare';
alert(message);