/* 

Skapa ett program som frågar efter namn och ålder samt sparar ner dessa i separata variabler.
Börja med att göra en flowchart och sedan skriva pseudokod, detta för att arbeta in förberedelsemetoder inför programmeringsproblem.

Beroende på vilken åldern användaren skriver in ska olika popups komma upp. Dessa ska ni styra med if/else statements.

följande regler ska gälla:

* programmet ska svara med namnet innan den skriver ut reglerna

* om personen är under 15, visa texten "Du måste ha hjälm när du cyklar"

* om personen är under 18, visa texten "Du får inte rösta"

* om personen är under 23, visa texten "Det blir ingen finlandsfärga"

* om personen är över 23, visa texten "Du är gammal nog att göra vad du vill"

Programmet ska bete sig enligt följande när du är klar:

Hej, vad heter du? :Micke
Ok Micke, hur gammal är du? :17

Du får inte rösta, Micke!
Det blir ingen finlandsfärga, Micke!

*/


// Lösningsförslag 1
// let name = prompt('Hej, vad heter du?');
// console.log(name);
// var age = prompt("Hej " + name + "! hur gammal är du?");
// console.log(age);

// if (age < 15) {
//     console.log(`Du måste ha hjälm när du cyklar, ${name}`);
// }

// if (age < 18 ) {
//     console.log(`Du får inte rösta, ${name}`);
// } 

// if (age < 23 ) {
//     console.log(`Det blir ingen finlandsfärga, ${name}`);
// } 

// if (age > 23 ) {
//     console.log(`Du är gammal nog att göra vad du vill, ${name}`);
// }




// Lösningsförslag 2
let name = prompt('Vad heter du?');
console.log(name);
let age = prompt("Okej " + name + ` Hur gammal är du?`)
console.log(age);
let message = '';

if (age < 15) {
    message += "Du måste ha hjälm när du cyklar\n";
    // alert(message);
    console.log(message);
}
if (age < 18) {
    message += "Du får inte rösta\n";
    // alert(message);
    console.log(message);
}
if (age < 23) {
    message += "Det blir ingen finlandsfärga\n";
    // alert(message);
    console.log(message);
}
if (age > 23) {
    message += "Du är gammal nog att göra vad du vill\n";
    // alert(message);
    console.log(message);
}

alert(message);