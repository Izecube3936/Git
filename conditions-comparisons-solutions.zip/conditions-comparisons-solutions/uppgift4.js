/*
Ni ska programmera ett spel som går ut på att användaren ska gissa ett slumpvalt nummer 
mellan 0 och 10 som programmet har slumpat fram i förväg. 
Om spelaren gissar fel så ska den få ett försök till (totalt 2 gissningar) 
tillsammans med en text som berättar om gissningen var för hög eller för låg. 
Om spelaren gissar rätt ska spelet meddela spelaren att den har vunnit. 

Gör leken i verkligheten tillsammans med en bordskamrat och tänk efter hur ni gör denna process, detta kommer att underlätta tänkandet.

När ni har fått en känsla för hur detta utspelar sig mellan två människor ska ni översätta det för datorn. 
Börja med att göra en flowchart som beskriver processen. 
Gå sedan vidare och skriv pseudokod. 
Nedan finner ni en startkod för hur man gör ett slumpvalt nummer.
*/ 

//Tar ett slumpvalt värde mellan 0 och 10
let number = Math.random();
console.log(number);
number = number * 10;
console.log(number);
number = Math.round(number);
console.log(number);


/* FORTSÄTT MED EGEN KOD HÄR */

let userInput = prompt(`Gissa tal mellan 0-10. CHEAT (${number})`);
if (userInput === number) {
    alert('Grattis');
} else {
    if (userInput > number) {
        userInput = prompt('För högt, gissa igen');
    } else {
        userInput = prompt('För lågt, gissa igen');
    }

    if (userInput == number) {
        alert('Grattis');
    } else {
        alert('Sämst');
    }
}
